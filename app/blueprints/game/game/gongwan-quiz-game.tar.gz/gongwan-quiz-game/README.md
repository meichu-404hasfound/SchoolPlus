# Gongwan Tycoon - Web Quiz Game

A web-based quiz game built with Flask backend and HTML/CSS/JavaScript frontend. Players answer multiple-choice questions to earn points and "Gongwan" coins.

## Features

- **Interactive Web Interface**: Modern, responsive design with smooth animations
- **Multiple Game Screens**: Main menu, level selection, gameplay, and results screens
- **Real-time Scoring**: Points are awarded for correct answers and deducted for incorrect ones
- **Level Completion**: Pass/fail determination based on correct answer count
- **Gongwan Rewards**: Earn virtual "Gongwan" coins based on performance
- **RESTful API**: Clean separation between frontend and backend logic

## Technology Stack

### Backend
- **Flask**: Python web framework
- **Flask-CORS**: Cross-origin resource sharing support
- **Python**: Game logic and API endpoints

### Frontend
- **HTML5**: Semantic markup structure
- **CSS3**: Modern styling with gradients, animations, and responsive design
- **JavaScript**: Interactive functionality and API communication

## Project Structure

```
gongwan-quiz-game/
├── src/
│   ├── static/
│   │   ├── index.html      # Main game interface
│   │   ├── styles.css      # Game styling and animations
│   │   └── script.js       # Frontend game logic
│   ├── routes/
│   │   ├── quiz.py         # Quiz API endpoints
│   │   └── user.py         # User management (template)
│   ├── models/
│   │   └── user.py         # Database models (template)
│   ├── game_logic.py       # Core game logic
│   └── main.py             # Flask application entry point
├── venv/                   # Virtual environment
├── requirements.txt        # Python dependencies
└── README.md              # This file
```

## API Endpoints

### Quiz Game API (`/api/quiz/`)

- `POST /start` - Start a new game session
- `GET /question` - Get the current question
- `POST /answer` - Submit an answer
- `GET /results` - Get game results
- `POST /reset` - Reset the current game

## How to Run Locally

### Prerequisites
- Python 3.6 or higher
- pip (Python package installer)

### Installation Steps

1. **Clone or download the project files**
   ```bash
   # Navigate to the project directory
   cd gongwan-quiz-game
   ```

2. **Create and activate virtual environment**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   python src/main.py
   ```

5. **Open your browser**
   Navigate to `http://localhost:5000` to play the game

### Troubleshooting `unable to open database file` error

If you encounter `sqlalchemy.exc.OperationalError: (sqlite3.OperationalError) unable to open database file` when running `python src/main.py`, it usually means the application doesn't have the necessary permissions to create or write to the database file in the specified location. This can happen if the directory for the database (`src/database/`) doesn't exist or if your user account lacks write permissions for that directory.

I've updated `src/main.py` to automatically create the `src/database` directory if it doesn't exist. Please ensure that the `gongwan-quiz-game` folder and its contents have appropriate write permissions for your user account.

## Game Instructions

1. **Main Menu**: Click "Start Game" to begin or "Level Select" to choose a specific level
2. **Gameplay**: Read each question and click on one of the four answer options
3. **Scoring**: 
   - Correct answers: +10 points
   - Incorrect answers: -5 points
4. **Level Completion**: Answer more than half the questions correctly to pass
5. **Rewards**: Earn Gongwan coins based on your performance
6. **Results**: View your final score, correct/incorrect counts, and earned coins

## Customization

### Adding New Questions

Edit the `questions_data` list in `src/game_logic.py`:

```python
questions_data = [
    {
        "question": "Your question here?",
        "options": ["Option A", "Option B", "Option C", "Option D"],
        "answer": 0,  # Index of correct answer (0-3)
        "score_correct": 10,
        "score_wrong": -5
    },
    # Add more questions...
]
```

### Modifying Game Rules

Adjust the game logic in the `GameLogic` class in `src/game_logic.py`:
- Change scoring values
- Modify pass/fail criteria
- Adjust Gongwan coin calculation

### Styling Changes

Customize the appearance by editing `src/static/styles.css`:
- Colors and gradients
- Animations and transitions
- Layout and typography

## Deployment

This application is ready for deployment to platforms like Heroku, Railway, or any cloud provider that supports Python web applications.

### Key Deployment Notes
- The app listens on `0.0.0.0` for external access
- CORS is enabled for frontend-backend communication
- All dependencies are listed in `requirements.txt`
- Static files are served from the Flask application

## Browser Compatibility

The game works on all modern browsers including:
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Mobile Support

The game is fully responsive and works on mobile devices with touch support.

---

Enjoy playing Gongwan Tycoon! 🥟

