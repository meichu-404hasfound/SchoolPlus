// Game state management
let currentScreen = 'main-menu';
let sessionId = 'player_' + Date.now();
let isAnswering = false;

// API base URL
const API_BASE = '/api/quiz';

// Screen management functions
function showScreen(screenId) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    
    // Show target screen
    document.getElementById(screenId).classList.add('active');
    currentScreen = screenId;
}

function showMainMenu() {
    showScreen('main-menu');
}

function showLevelSelect() {
    showScreen('level-select');
}

function showLoading() {
    showScreen('loading');
}

function showGameplay() {
    showScreen('gameplay');
}

function showResults() {
    showScreen('results');
}

// Game flow functions
async function startGame() {
    showLoading();
    
    try {
        // Start a new game session
        const response = await fetch(`${API_BASE}/start`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                session_id: sessionId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            await loadQuestion();
        } else {
            alert('Failed to start game: ' + data.message);
            showMainMenu();
        }
    } catch (error) {
        console.error('Error starting game:', error);
        alert('Failed to start game. Please try again.');
        showMainMenu();
    }
}

async function selectLevel(levelNumber) {
    // For now, we only have one level, so just start the game
    await startGame();
}

async function loadQuestion() {
    try {
        const response = await fetch(`${API_BASE}/question?session_id=${sessionId}`);
        const data = await response.json();
        
        if (data.success) {
            if (data.finished) {
                await loadResults();
            } else {
                displayQuestion(data);
                showGameplay();
            }
        } else {
            alert('Failed to load question: ' + data.message);
            showMainMenu();
        }
    } catch (error) {
        console.error('Error loading question:', error);
        alert('Failed to load question. Please try again.');
        showMainMenu();
    }
}

function displayQuestion(questionData) {
    // Update score and question counter
    document.getElementById('current-score').textContent = `Score: ${questionData.current_score}`;
    document.getElementById('question-counter').textContent = 
        `Question ${questionData.question_number}/${questionData.total_questions}`;
    
    // Display question text
    document.getElementById('question-text').textContent = questionData.question;
    
    // Clear previous options and feedback
    const optionsContainer = document.getElementById('options-container');
    const feedbackContainer = document.getElementById('feedback-container');
    optionsContainer.innerHTML = '';
    feedbackContainer.innerHTML = '';
    
    // Create option buttons
    questionData.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.className = 'option-btn';
        button.textContent = option;
        button.onclick = () => submitAnswer(index);
        optionsContainer.appendChild(button);
    });
    
    isAnswering = false;
}

async function submitAnswer(selectedOption) {
    if (isAnswering) return; // Prevent multiple submissions
    isAnswering = true;
    
    try {
        const response = await fetch(`${API_BASE}/answer`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                session_id: sessionId,
                selected_option: selectedOption
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Show feedback
            displayFeedback(data.is_correct, data.message);
            
            // Highlight the selected option
            const optionButtons = document.querySelectorAll('.option-btn');
            optionButtons[selectedOption].classList.add(data.is_correct ? 'correct' : 'incorrect');
            
            // Disable all option buttons
            optionButtons.forEach(btn => {
                btn.disabled = true;
                btn.style.cursor = 'not-allowed';
            });
            
            // Update score
            document.getElementById('current-score').textContent = `Score: ${data.current_score}`;
            
            // Wait a moment, then load next question or results
            setTimeout(async () => {
                if (data.finished) {
                    await loadResults();
                } else {
                    await loadQuestion();
                }
            }, 2000);
            
        } else {
            alert('Failed to submit answer: ' + data.message);
            isAnswering = false;
        }
    } catch (error) {
        console.error('Error submitting answer:', error);
        alert('Failed to submit answer. Please try again.');
        isAnswering = false;
    }
}

function displayFeedback(isCorrect, message) {
    const feedbackContainer = document.getElementById('feedback-container');
    const feedbackDiv = document.createElement('div');
    feedbackDiv.className = `feedback-message ${isCorrect ? 'correct' : 'incorrect'}`;
    feedbackDiv.textContent = message;
    feedbackContainer.appendChild(feedbackDiv);
}

async function loadResults() {
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE}/results?session_id=${sessionId}`);
        const data = await response.json();
        
        if (data.success) {
            displayResults(data.results);
            showResults();
        } else {
            alert('Failed to load results: ' + data.message);
            showMainMenu();
        }
    } catch (error) {
        console.error('Error loading results:', error);
        alert('Failed to load results. Please try again.');
        showMainMenu();
    }
}

function displayResults(results) {
    document.getElementById('final-score').textContent = results.final_score;
    document.getElementById('correct-count').textContent = results.correct_count;
    document.getElementById('incorrect-count').textContent = results.incorrect_count;
    document.getElementById('level-passed').textContent = results.passed_level ? 'Yes' : 'No';
    document.getElementById('gongwan-coins').textContent = results.gongwan_coins_earned;
}

async function replayLevel() {
    showLoading();
    
    try {
        // Reset the current game session
        const response = await fetch(`${API_BASE}/reset`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                session_id: sessionId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            await loadQuestion();
        } else {
            alert('Failed to reset game: ' + data.message);
            showMainMenu();
        }
    } catch (error) {
        console.error('Error resetting game:', error);
        alert('Failed to reset game. Please try again.');
        showMainMenu();
    }
}

function quitGame() {
    if (confirm('Are you sure you want to quit the game?')) {
        // In a real application, you might want to clean up the session
        showMainMenu();
    }
}

// Initialize the game when the page loads
document.addEventListener('DOMContentLoaded', function() {
    showMainMenu();
});

